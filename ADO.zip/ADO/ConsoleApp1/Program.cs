﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection("data source=.;database= Db1; integrated Security = SSPI");
            SqlCommand cmd = new SqlCommand("count_names_with_id", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@name", System.Data.SqlDbType.VarChar));
            cmd.Parameters["@name"].Value = "Rishikesh";
            cmd.Parameters.Add(new SqlParameter("@out", System.Data.SqlDbType.Int));
            cmd.Parameters["@out"].Direction = System.Data.ParameterDirection.Output;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Console.WriteLine(cmd.Parameters["@out"].Value.ToString());


        }
    }
}
