﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection("data source=.;database= Db1; integrated Security = SSPI");
            SqlCommand cmd = new SqlCommand("Select * from Student;", con);
            //SqlCommand cmd = new SqlCommand("Insert Into Student(id,StudentName,Age,ClassTeacherID) Values(4,'Rishikesh',23,3);", con);
            //SqlCommand cmd = new SqlCommand("Delete from Student where id = 4", con);
            //SqlCommand cmd = new SqlCommand("Update Student set age = 23 where id = 3", con);
           // con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
           // con.Close();
            DataTable dataTable = new DataTable();           
            adapter.Fill(dataTable);
            //DataTableReader read = new DataTableReader(dataTable);
            foreach (DataColumn col in dataTable.Columns)
            {
                Console.Write("{0,-14}",col.ColumnName);
            }
            Console.WriteLine();

            foreach (DataRow row in dataTable.Rows)
            {
                foreach (DataColumn col in dataTable.Columns)
                {
                    Console.Write("{0,-14}",row[col]);
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }
}
