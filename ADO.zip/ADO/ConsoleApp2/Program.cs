﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con = new SqlConnection("data source =. ; database= Db1; integrated security = SSPI");
            //SqlCommand cmd = new SqlCommand("Select *  from Student",con);
            //SqlCommand cmd = new SqlCommand("Select SUM(Age)  from Student", con);
            //SqlCommand cmd = new SqlCommand("Insert Into Student(id,StudentName,Age,ClassTeacherID) Values(4,'Rishikesh',23,3);", con);
            //SqlCommand cmd = new SqlCommand("Delete from Student where id = 4", con);
            SqlCommand cmd = new SqlCommand("Update Student Set Age = 22 where id = 3", con);
            con.Open();

            try
            {
                SqlDataReader rdr = cmd.ExecuteReader();
                //Int32 count =(Int32) cmd.ExecuteScalar();
                
                for (int i = 0; i < rdr.FieldCount; i++)
                    Console.Write(rdr.GetName(i)+ "\t");
                Console.WriteLine();
                while (rdr.Read())
                {
                    for (int i = 0; i < rdr.FieldCount; i++)
                    {
                        Console.Write(rdr.GetValue(i) + "\t");
                    }
                    Console.WriteLine();
                }
                
                //Console.WriteLine("Sum of ages:"+count);
            }
            catch
            {
                throw new Exception("Couldn't read from table");
            }
            finally
            {
                con.Close();
            }
            Console.Read();
        }
    }
}
